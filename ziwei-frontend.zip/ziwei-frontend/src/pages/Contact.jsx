import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { sendContact } from '../services/api'
import Stars from '../components/Stars'

export default function Contact() {
  const nav  = useNavigate()
  const [form, setForm] = useState({ name:'', email:'', subject:'', message:'' })
  const [status, setStatus] = useState('') // '' | 'loading' | 'done' | 'error'

  function set(k, v) { setForm(f => ({...f, [k]:v})) }

  async function handleSubmit(e) {
    e.preventDefault()
    if (!form.name||!form.email||!form.subject||!form.message)
      return alert('모든 항목을 입력해주세요.')
    setStatus('loading')
    try {
      await sendContact(form)
      setStatus('done')
    } catch {
      setStatus('error')
    }
  }

  return (
    <div style={{ minHeight:'100vh' }}>
      <Stars />
      <header style={{ padding:'18px 20px' }}>
        <button onClick={() => nav(-1)}
          style={{ background:'transparent', border:'none',
                   color:'var(--text2)', fontSize:13, cursor:'pointer' }}>
          ← 뒤로
        </button>
      </header>

      <main style={{ maxWidth:480, margin:'0 auto', padding:'20px 16px 60px' }}>
        <h1 style={{ fontFamily:'var(--font-serif)', fontSize:26,
                     color:'var(--lavender2)', marginBottom:8, textAlign:'center' }}>
          문의하기
        </h1>
        <p style={{ fontSize:13, color:'var(--text3)', textAlign:'center', marginBottom:32 }}>
          궁금한 점이 있으시면 편하게 문의해 주세요
        </p>

        {status === 'done' ? (
          <div style={{ background:'rgba(122,255,184,0.08)',
                        border:'1px solid rgba(122,255,184,0.2)',
                        borderRadius:16, padding:'40px 24px', textAlign:'center' }}>
            <div style={{ fontSize:40, marginBottom:16 }}>✉️</div>
            <p style={{ color:'var(--success)', fontSize:16, marginBottom:8 }}>
              문의가 접수되었습니다
            </p>
            <p style={{ color:'var(--text3)', fontSize:13 }}>
              입력하신 이메일로 답변을 드리겠습니다
            </p>
            <button onClick={() => nav('/')} style={{ ...btnSt, marginTop:24 }}>
              홈으로 돌아가기
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit}
            style={{ background:'var(--card)', border:'1px solid var(--border)',
                     borderRadius:16, padding:'28px 24px' }}>
            {[
              { key:'name',    label:'이름',  placeholder:'이름을 입력해주세요', type:'text' },
              { key:'email',   label:'이메일', placeholder:'답변 받으실 이메일', type:'email' },
              { key:'subject', label:'제목',  placeholder:'문의 제목', type:'text' },
            ].map(f => (
              <div key={f.key} style={{ marginBottom:16 }}>
                <label style={labelSt}>{f.label}</label>
                <input type={f.type} placeholder={f.placeholder}
                  value={form[f.key]} onChange={e => set(f.key, e.target.value)}
                  style={inputSt} />
              </div>
            ))}
            <div style={{ marginBottom:24 }}>
              <label style={labelSt}>문의 내용</label>
              <textarea placeholder="문의 내용을 입력해주세요"
                value={form.message} onChange={e => set('message', e.target.value)}
                rows={5}
                style={{ ...inputSt, resize:'vertical', minHeight:120 }} />
            </div>

            {status === 'error' && (
              <p style={{ color:'var(--danger)', fontSize:13, marginBottom:12 }}>
                전송 오류가 발생했습니다. 다시 시도해주세요.
              </p>
            )}

            <button type="submit" disabled={status==='loading'} style={btnSt}>
              {status==='loading' ? '전송 중...' : '문의 보내기'}
            </button>
          </form>
        )}
      </main>
    </div>
  )
}

const labelSt = { display:'block', fontSize:13, color:'var(--text2)', marginBottom:6 }
const inputSt = {
  width:'100%', padding:'11px 14px',
  background:'rgba(255,255,255,0.04)',
  border:'1px solid var(--border)', borderRadius:10,
  color:'var(--text)', fontSize:14, outline:'none',
}
const btnSt = {
  width:'100%', padding:'14px', borderRadius:12,
  background:'linear-gradient(135deg,#7c3aed,#c026d3)',
  border:'none', color:'#fff', fontSize:15, fontWeight:600,
  cursor:'pointer',
}
