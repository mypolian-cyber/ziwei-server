import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import MingbanChart from '../components/MingbanChart'
import Payment from '../components/Payment'
import Stars from '../components/Stars'
import { calcPaid } from '../services/api'

export default function Result() {
  const nav = useNavigate()
  const [result,  setResult]  = useState(null)
  const [input,   setInput]   = useState(null)
  const [paid,    setPaid]    = useState(null)  // { reading, service_type }
  const [showPay, setShowPay] = useState(false)
  const [loading, setLoading] = useState(false)

  // 특정일 입력
  const [queryMonth, setQueryMonth] = useState('')
  const [queryDay,   setQueryDay]   = useState('')
  const [showDayInput, setShowDayInput] = useState(false)

  useEffect(() => {
    const r = sessionStorage.getItem('ziwei_result')
    const i = sessionStorage.getItem('ziwei_input')
    if (!r || !i) { nav('/'); return }
    setResult(JSON.parse(r))
    setInput(JSON.parse(i))

    // 결제 후 복귀 시 처리
    const payKey   = sessionStorage.getItem('payment_key')
    const cacheKey = sessionStorage.getItem('cache_key')
    const svcType  = sessionStorage.getItem('pending_service')
    if (payKey && cacheKey && svcType) {
      fetchPaid(JSON.parse(i), svcType, payKey)
      sessionStorage.removeItem('payment_key')
      sessionStorage.removeItem('cache_key')
      sessionStorage.removeItem('pending_service')
    }
  }, [])

  async function fetchPaid(inp, svcType, payKey, qMonth, qDay) {
    setLoading(true)
    try {
      const full = await calcPaid(
        { ...inp, query_month: qMonth||null, query_day: qDay||null },
        svcType, payKey
      )
      setPaid({ reading: full.reading, service_type: svcType })
    } catch(e) {
      alert('운세 불러오기 오류: ' + e.message)
    } finally {
      setLoading(false)
    }
  }

  if (!result) return null
  const mb = result.mingban
  const ln = mb.liunian
  const dx = mb.currentDaxian

  return (
    <div style={{ minHeight:'100vh' }}>
      <Stars />

      {/* 헤더 */}
      <header style={{ padding:'18px 20px', display:'flex',
                       justifyContent:'space-between', alignItems:'center' }}>
        <button onClick={() => nav('/')}
          style={{ background:'transparent', border:'none',
                   color:'var(--text2)', fontSize:13, cursor:'pointer' }}>
          ← 다시 입력
        </button>
        <span style={{ fontFamily:'var(--font-serif)', fontSize:16,
                       color:'var(--gold)' }}>紫微命盤</span>
        <div style={{ width:60 }} />
      </header>

      <main style={{ maxWidth:540, margin:'0 auto', padding:'0 16px 60px' }}>

        {/* 명반 원형 차트 */}
        <section style={{ animation:'fadeUp 0.6s ease', marginBottom:32 }}>
          <div style={{ textAlign:'center', marginBottom:16 }}>
            <span style={{ fontSize:12, letterSpacing:'0.2em',
                           color:'var(--lavender)', textTransform:'uppercase' }}>
              나의 명반
            </span>
          </div>
          <MingbanChart palaces={mb.palaces} />
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)',
                        gap:8, marginTop:20 }}>
            {[
              ['명궁', mb.mingGongZhi],
              ['오행국', mb.wuXingJu],
              ['현재 대한', `${dx.ageStart}~${dx.ageEnd}세`],
            ].map(([k,v]) => (
              <div key={k} style={{ background:'var(--card)',
                                    border:'1px solid var(--border)',
                                    borderRadius:10, padding:'12px 8px',
                                    textAlign:'center' }}>
                <div style={{ fontSize:11, color:'var(--text3)', marginBottom:4 }}>{k}</div>
                <div style={{ fontFamily:'var(--font-serif)', fontSize:15,
                              color:'var(--lavender2)' }}>{v}</div>
              </div>
            ))}
          </div>
        </section>

        {/* 무료 미리보기 */}
        <section style={{ background:'var(--card)', border:'1px solid var(--border)',
                          borderRadius:16, padding:'22px 20px', marginBottom:20,
                          animation:'fadeUp 0.7s ease' }}>
          <div style={{ fontSize:12, color:'var(--lavender)', marginBottom:12,
                        letterSpacing:'0.1em' }}>무료 미리보기</div>
          <p style={{ fontSize:14, color:'var(--text2)', lineHeight:1.9 }}>
            {result.reading}
          </p>
        </section>

        {/* 유년 사화 */}
        <section style={{ marginBottom:20, animation:'fadeUp 0.8s ease' }}>
          <div style={{ fontSize:12, color:'var(--text3)', marginBottom:10,
                        letterSpacing:'0.1em' }}>
            {ln.year}년 유년 사화(流年 四化)
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(2,1fr)', gap:8 }}>
            {Object.entries(ln.siHuaKr).map(([star, sihua]) => (
              <div key={star}
                style={{ background: sihua==='화기' ? 'rgba(255,107,138,0.08)' : 'rgba(180,142,255,0.06)',
                         border:`1px solid ${sihua==='화기' ? 'rgba(255,107,138,0.2)' : 'var(--border)'}`,
                         borderRadius:10, padding:'12px 14px',
                         display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <span style={{ fontFamily:'var(--font-serif)', fontSize:14,
                               color: sihua==='화기' ? 'var(--rose)' : 'var(--lavender2)' }}>
                  {star}
                </span>
                <span style={{ fontSize:13, color:'var(--text2)' }}>{sihua}</span>
              </div>
            ))}
          </div>
        </section>

        {/* 월별 유월 */}
        <section style={{ marginBottom:28, animation:'fadeUp 0.9s ease' }}>
          <div style={{ fontSize:12, color:'var(--text3)', marginBottom:10,
                        letterSpacing:'0.1em' }}>{ln.year}년 월별 유월명궁</div>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:6 }}>
            {ln.liuyue.map(m => (
              <div key={m.month}
                style={{ background:'var(--card)', border:'1px solid var(--border)',
                         borderRadius:10, padding:'10px 6px', textAlign:'center' }}>
                <div style={{ fontSize:11, color:'var(--text3)', marginBottom:4 }}>{m.month}월</div>
                <div style={{ fontFamily:'var(--font-serif)', fontSize:12,
                              color:'var(--lavender2)' }}>{m.natalPalaceKr.replace('궁','')}</div>
              </div>
            ))}
          </div>
        </section>

        {/* 유료 결과 표시 */}
        {loading && (
          <div style={{ textAlign:'center', padding:'40px 0' }}>
            <div style={{ width:36, height:36, border:'3px solid rgba(180,142,255,0.2)',
                          borderTopColor:'var(--lavender)', borderRadius:'50%',
                          animation:'spin 0.8s linear infinite', margin:'0 auto 16px' }} />
            <p style={{ color:'var(--text2)', fontSize:14 }}>GPT-4o가 직언 중...</p>
          </div>
        )}

        {paid && !loading && (
          <section style={{ background:'var(--card)',
                            border:'1px solid rgba(201,168,76,0.3)',
                            borderRadius:16, padding:'24px 20px', marginBottom:20,
                            animation:'fadeUp 0.5s ease' }}>
            <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:16 }}>
              <span style={{ fontSize:16 }}>
                {paid.service_type==='ziwei_year' ? '🌙' : '⭐'}
              </span>
              <span style={{ fontFamily:'var(--font-serif)', fontSize:16, color:'var(--gold)' }}>
                {paid.service_type==='ziwei_year' ? '해별 운세' : '특정일 운세'}
              </span>
            </div>
            <div style={{ fontSize:14, color:'var(--text)', lineHeight:2,
                          whiteSpace:'pre-wrap' }}>
              {paid.reading}
            </div>
          </section>
        )}

        {/* 특정일 입력 (해별 결제 완료 후 또는 별도) */}
        {showDayInput && (
          <section style={{ background:'var(--card)', border:'1px solid var(--border)',
                            borderRadius:16, padding:'22px 20px', marginBottom:20,
                            animation:'fadeUp 0.4s ease' }}>
            <div style={{ fontFamily:'var(--font-serif)', fontSize:16,
                          color:'var(--lavender2)', marginBottom:16 }}>
              ⭐ 특정일 운세
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:16 }}>
              <div>
                <label style={{ fontSize:12, color:'var(--text3)', display:'block', marginBottom:6 }}>월</label>
                <select value={queryMonth} onChange={e => setQueryMonth(e.target.value)}
                  style={selectSt}>
                  <option value="">월 선택</option>
                  {Array.from({length:12},(_,i) =>
                    <option key={i+1} value={i+1}>{i+1}월</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize:12, color:'var(--text3)', display:'block', marginBottom:6 }}>일</label>
                <select value={queryDay} onChange={e => setQueryDay(e.target.value)}
                  style={selectSt}>
                  <option value="">일 선택</option>
                  {Array.from({length:31},(_,i) =>
                    <option key={i+1} value={i+1}>{i+1}일</option>)}
                </select>
              </div>
            </div>
            <button onClick={() => {
              if (!queryMonth||!queryDay) return alert('월과 일을 선택해주세요.')
              setShowPay(true)
            }}
              style={{ ...btnSt, width:'100%' }}>
              이 날 운세 보기 (1,990원)
            </button>
          </section>
        )}

        {/* CTA 버튼 */}
        {!paid && !loading && (
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            <button onClick={() => setShowPay(true)} style={btnSt}>
              🌙 해별 운세 전체 보기 — 1,990원
            </button>
            <button onClick={() => setShowDayInput(!showDayInput)}
              style={{ ...btnSt,
                       background:'transparent',
                       border:'1px solid var(--border)',
                       color:'var(--text2)' }}>
              ⭐ 특정일 운세 보기 — 1,990원
            </button>
          </div>
        )}
      </main>

      {showPay && (
        <Payment
          cacheKey={result.cache_key}
          input={{ ...input, query_month: queryMonth||null, query_day: queryDay||null }}
          onClose={() => setShowPay(false)}
        />
      )}
    </div>
  )
}

const btnSt = {
  width:'100%', padding:'15px', borderRadius:12,
  background:'linear-gradient(135deg,#7c3aed,#c026d3)',
  border:'none', color:'#fff', fontSize:15, fontWeight:600,
  cursor:'pointer', letterSpacing:'0.04em',
  boxShadow:'0 4px 24px rgba(124,58,237,0.35)',
}
const selectSt = {
  width:'100%', padding:'10px 12px',
  background:'rgba(255,255,255,0.04)',
  border:'1px solid var(--border)',
  borderRadius:10, color:'var(--text)',
  fontSize:14, outline:'none',
}
