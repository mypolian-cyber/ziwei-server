import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { calcFree } from '../services/api'
import Stars from '../components/Stars'

const HOURS = [
  { value:'0',  label:'자시 (23:00 ~ 01:00)' },
  { value:'2',  label:'축시 (01:00 ~ 03:00)' },
  { value:'4',  label:'인시 (03:00 ~ 05:00)' },
  { value:'6',  label:'묘시 (05:00 ~ 07:00)' },
  { value:'8',  label:'진시 (07:00 ~ 09:00)' },
  { value:'10', label:'사시 (09:00 ~ 11:00)' },
  { value:'12', label:'오시 (11:00 ~ 13:00)' },
  { value:'14', label:'미시 (13:00 ~ 15:00)' },
  { value:'16', label:'신시 (15:00 ~ 17:00)' },
  { value:'18', label:'유시 (17:00 ~ 19:00)' },
  { value:'20', label:'술시 (19:00 ~ 21:00)' },
  { value:'22', label:'해시 (21:00 ~ 23:00)' },
]

export default function Home() {
  const nav = useNavigate()
  const [form, setForm] = useState({ year:'', month:'', day:'', hour:'', is_male:'' })
  const [err,  setErr]  = useState('')
  const [loading, setLoading] = useState(false)
  const [showHourInfo, setShowHourInfo] = useState(false)

  function set(k, v) { setForm(f => ({ ...f, [k]: v })); setErr('') }

  async function handleSubmit(e) {
    e.preventDefault()
    if (!form.year||!form.month||!form.day) return setErr('생년월일을 모두 입력해주세요.')
    if (!form.hour && form.hour !== 0)      return setErr('태어난 시(時)는 필수입니다. 모르신다면 아래 안내를 확인하세요.')
    if (form.is_male === '')                return setErr('성별을 선택해주세요.')

    const input = {
      year: Number(form.year), month: Number(form.month),
      day: Number(form.day),   hour: Number(form.hour),
      is_male: form.is_male === 'true',
      current_year: new Date().getFullYear(),
      age: new Date().getFullYear() - Number(form.year),
    }

    setLoading(true)
    try {
      const result = await calcFree(input)
      sessionStorage.setItem('ziwei_input',  JSON.stringify(input))
      sessionStorage.setItem('ziwei_result', JSON.stringify(result))
      nav('/result')
    } catch(e) {
      setErr('오류가 발생했습니다. 잠시 후 다시 시도해주세요.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ minHeight:'100vh', display:'flex', flexDirection:'column' }}>
      <Stars />

      {/* 헤더 */}
      <header style={{ padding:'20px 24px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div style={{ fontFamily:'var(--font-serif)', fontSize:18, color:'var(--gold)', letterSpacing:'0.1em' }}>
          紫微斗數
        </div>
        <button onClick={() => nav('/contact')}
          style={{ background:'transparent', border:'1px solid var(--border)',
                   color:'var(--text2)', padding:'6px 14px', borderRadius:20,
                   fontSize:13, cursor:'pointer' }}>
          문의하기
        </button>
      </header>

      {/* 히어로 */}
      <section style={{ textAlign:'center', padding:'48px 24px 40px', animation:'fadeUp 0.8s ease' }}>
        <div style={{ fontSize:13, letterSpacing:'0.25em', color:'var(--lavender)',
                      marginBottom:16, textTransform:'uppercase' }}>
          자미두수 예언소
        </div>
        <h1 style={{ fontFamily:'var(--font-serif)', fontSize:'clamp(28px,7vw,52px)',
                     lineHeight:1.3, marginBottom:16,
                     background:'linear-gradient(135deg, #e8c97a 0%, #d4bbff 50%, #e8a0bf 100%)',
                     WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent' }}>
          애매한 운세는 없다
        </h1>
        <p style={{ fontSize:'clamp(14px,3.5vw,18px)', color:'var(--text2)', marginBottom:8 }}>
          확실한 답만 드립니다
        </p>
        <p style={{ fontSize:13, color:'var(--text3)', maxWidth:400, margin:'0 auto' }}>
          별자리의 정밀 계산으로 당신의 해별 운세와<br/>특정일의 운명을 직언합니다
        </p>
      </section>

      {/* 입력 폼 */}
      <main style={{ flex:1, display:'flex', justifyContent:'center', padding:'0 16px 40px' }}>
        <div style={{ width:'100%', maxWidth:480 }}>
          <form onSubmit={handleSubmit}
            style={{ background:'var(--card)', border:'1px solid var(--border)',
                     borderRadius:var_radius, padding:'32px 28px' }}>

            <h2 style={{ fontFamily:'var(--font-serif)', fontSize:20,
                         color:'var(--lavender2)', marginBottom:28, textAlign:'center' }}>
              명반 정보 입력
            </h2>

            {/* 생년월일 */}
            <div style={{ marginBottom:20 }}>
              <label style={labelStyle}>생년월일 (양력)</label>
              <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr 1fr', gap:8 }}>
                <input type="number" placeholder="출생 연도 (예: 1995)"
                  value={form.year} onChange={e => set('year', e.target.value)}
                  min="1900" max="2010" style={inputStyle} />
                <select value={form.month} onChange={e => set('month', e.target.value)} style={inputStyle}>
                  <option value="">월</option>
                  {Array.from({length:12},(_,i)=>
                    <option key={i+1} value={i+1}>{i+1}월</option>)}
                </select>
                <select value={form.day} onChange={e => set('day', e.target.value)} style={inputStyle}>
                  <option value="">일</option>
                  {Array.from({length:31},(_,i)=>
                    <option key={i+1} value={i+1}>{i+1}일</option>)}
                </select>
              </div>
            </div>

            {/* 생시 */}
            <div style={{ marginBottom:8 }}>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8 }}>
                <label style={labelStyle}>태어난 시(時) <span style={{ color:'var(--danger)', fontSize:12 }}>필수</span></label>
                <button type="button" onClick={() => setShowHourInfo(!showHourInfo)}
                  style={{ background:'transparent', border:'none', color:'var(--lavender)',
                           fontSize:12, cursor:'pointer', textDecoration:'underline' }}>
                  생시를 모르신다면?
                </button>
              </div>
              <select value={form.hour} onChange={e => set('hour', e.target.value)} style={inputStyle}>
                <option value="">태어난 시(時) 선택</option>
                {HOURS.map(h => <option key={h.value} value={h.value}>{h.label}</option>)}
              </select>
            </div>

            {/* 생시 모를 때 안내 */}
            {showHourInfo && (
              <div style={{ background:'rgba(255,107,138,0.08)', border:'1px solid rgba(255,107,138,0.25)',
                            borderRadius:10, padding:'14px 16px', marginBottom:16,
                            animation:'fadeUp 0.3s ease' }}>
                <p style={{ fontSize:13, color:'var(--rose)', fontWeight:500, marginBottom:6 }}>
                  ⚠️ 생시(태어난 시간)를 모르면 이용하실 수 없습니다
                </p>
                <p style={{ fontSize:12, color:'var(--text2)', lineHeight:1.7 }}>
                  자미두수는 태어난 시간을 기준으로 명궁(命宮)이 결정됩니다.
                  생시가 틀리거나 불분명하면 모든 분석 결과가 달라지므로,
                  정확한 생시 없이는 정확한 운세를 드릴 수 없습니다.
                </p>
                <p style={{ fontSize:12, color:'var(--text3)', marginTop:8 }}>
                  출생 병원 기록, 가족 증언 등으로 생시를 확인 후 이용해 주세요.
                </p>
              </div>
            )}

            {/* 성별 */}
            <div style={{ marginBottom:24 }}>
              <label style={labelStyle}>성별</label>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
                {[['true','여성 ♀'],['false','남성 ♂']].map(([v,l]) => (
                  <button key={v} type="button"
                    onClick={() => set('is_male', v)}
                    style={{
                      padding:'11px', borderRadius:10, fontSize:15, fontWeight:500,
                      border: form.is_male === v
                        ? '1px solid var(--lavender)' : '1px solid var(--border)',
                      background: form.is_male === v
                        ? 'rgba(180,142,255,0.15)' : 'transparent',
                      color: form.is_male === v ? 'var(--lavender2)' : 'var(--text2)',
                      cursor:'pointer', transition:'all 0.2s',
                    }}>
                    {l}
                  </button>
                ))}
              </div>
            </div>

            {/* 오류 */}
            {err && (
              <div style={{ background:'rgba(255,107,138,0.1)', border:'1px solid rgba(255,107,138,0.3)',
                            borderRadius:10, padding:'10px 14px', marginBottom:16,
                            fontSize:13, color:'var(--danger)' }}>
                {err}
              </div>
            )}

            {/* 제출 */}
            <button type="submit" disabled={loading}
              style={{ width:'100%', padding:'15px', borderRadius:12,
                       background: loading ? 'rgba(180,142,255,0.2)'
                         : 'linear-gradient(135deg, #7c3aed, #c026d3)',
                       border:'none', color:'#fff', fontSize:16,
                       fontWeight:600, letterSpacing:'0.05em',
                       cursor: loading ? 'not-allowed' : 'pointer',
                       transition:'all 0.3s',
                       boxShadow: loading ? 'none' : '0 4px 24px rgba(124,58,237,0.4)' }}>
              {loading
                ? <span style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
                    <span style={{ width:16, height:16, border:'2px solid rgba(255,255,255,0.3)',
                                   borderTopColor:'#fff', borderRadius:'50%',
                                   animation:'spin 0.7s linear infinite', display:'inline-block' }} />
                    명반 펼치는 중...
                  </span>
                : '✦  무료로 명반 확인하기'}
            </button>
          </form>

          {/* 서비스 안내 */}
          <div style={{ marginTop:24, display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            {[
              { icon:'🌙', title:'해별 운세', desc:'올해 12달\n직설적 분석', price:'1,990원' },
              { icon:'⭐', title:'특정일 운세', desc:'원하는 날\n길흉 직언', price:'1,990원' },
            ].map(s => (
              <div key={s.title}
                style={{ background:'var(--card)', border:'1px solid var(--border)',
                         borderRadius:14, padding:'18px 16px', textAlign:'center' }}>
                <div style={{ fontSize:24, marginBottom:8 }}>{s.icon}</div>
                <div style={{ fontFamily:'var(--font-serif)', fontSize:15,
                              color:'var(--lavender2)', marginBottom:4 }}>{s.title}</div>
                <div style={{ fontSize:12, color:'var(--text3)', whiteSpace:'pre-line',
                              marginBottom:8, lineHeight:1.6 }}>{s.desc}</div>
                <div style={{ fontSize:15, color:'var(--gold)', fontWeight:600 }}>{s.price}</div>
              </div>
            ))}
          </div>

          {/* 정확도 고지 */}
          <div style={{ marginTop:20, background:'rgba(180,142,255,0.05)',
                        border:'1px solid var(--border2)', borderRadius:12,
                        padding:'16px 18px' }}>
            <p style={{ fontSize:12, color:'var(--text3)', lineHeight:1.8 }}>
              <span style={{ color:'var(--lavender)', fontWeight:500 }}>📌 정확도 안내</span><br />
              자미두수는 생년·월·일·시(時) 4가지가 정확해야 올바른 명반이 산출됩니다.
              생시가 불분명하거나 틀릴 경우 모든 분석 결과가 달라질 수 있으며,
              이 경우 정확한 운세를 보장드리기 어렵습니다.
              입력 정보의 정확성은 이용자 본인이 확인하여 주시기 바랍니다.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}

const labelStyle = {
  display:'block', fontSize:13, color:'var(--text2)',
  marginBottom:8, letterSpacing:'0.03em',
}
const inputStyle = {
  width:'100%', padding:'11px 14px',
  background:'rgba(255,255,255,0.04)',
  border:'1px solid var(--border)',
  borderRadius:10, color:'var(--text)',
  fontSize:14, outline:'none',
  appearance:'none',
}
const var_radius = 'var(--radius)'
