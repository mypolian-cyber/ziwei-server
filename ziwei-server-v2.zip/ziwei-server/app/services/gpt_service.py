"""
자미두수 GPT 서비스 — 후아모의 gpt_service.py 패턴 동일
GPT-4o 사용, 마크다운 후처리 제거
"""
import os, re, asyncio
from openai import AsyncOpenAI
from dotenv import load_dotenv

load_dotenv()
client = AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))

SYSTEM = """당신은 자미두수(紫微斗數) 전문 역술가입니다.
규칙:
- "매사 조심하라", "무난한 한 해" 같은 미지근한 표현 절대 금지
- 돈이 들어오는 달, 계약이 깨지는 날, 이성운이 폭발하는 시기를 송곳처럼 직언
- 구체적 수치와 상황을 제시 (예: "3월 셋째 주, 계약서에 도장 찍지 마세요")
- 한자 용어 첫 등장 시 한글 병기
- 존댓말, 단호하고 자신감 있는 어조
- 볼드(**), 헤더(###), 구분선(---) 등 마크다운 기호 사용 금지"""

def _clean(text: str) -> str:
    """GPT 마크다운 기호 제거 — 후아모와 동일한 후처리"""
    text = re.sub(r'\*+', '', text)
    text = re.sub(r'#{1,6}\s*', '', text)
    text = re.sub(r'-{3,}', '', text)
    text = re.sub(r'_{1,}', '', text)
    return text.strip()

def _extract(mingban: dict, current_year: int) -> dict:
    """명반 dict → 프롬프트 변수"""
    ming  = next((p for p in mingban["palaces"] if p["isMingGong"]), None)
    stars = ", ".join(
        f"{s['name']}{s['brightness']}" + (f"({s['siHuaKr']})" if s["siHuaKr"] else "")
        for s in (ming["stars"] if ming else [])
    )
    dx = mingban["currentDaxian"]
    ln = mingban["liunian"]
    liuyue_str = "\n".join(
        f"  {m['month']}월: 유월명궁→{m['natalPalaceKr']}" for m in ln["liuyue"]
    )
    sihua_str = ", ".join(f"{s}→{h}" for s,h in ln.get("siHuaKr",{}).items())
    sihua_pal = ", ".join(f"{h}:{p}" for h,p in ln.get("siHuaPalacesKr",{}).items())
    palaces_str = "\n".join(
        f"  {p['nameKr']}[{p['ganZhi']}]: " +
        ", ".join(f"{s['name']}{s['brightness']}" + (f"({s['siHuaKr']})" if s["siHuaKr"] else "")
                  for s in p["stars"])
        for p in mingban["palaces"]
    )
    return dict(
        ming_gong_zhi=mingban["mingGongZhi"],
        shen_gong_zhi=mingban["shenGongZhi"],
        wu_xing_ju=mingban["wuXingJu"],
        ming_stars=stars,
        dax_age=f"{dx['ageStart']}~{dx['ageEnd']}",
        dax_palace=dx["palaceNameKr"],
        dax_ganzhi=dx["ganZhi"],
        dax_stars=", ".join(dx["mainStars"]),
        current_year=current_year,
        liunian_palace=ln["natalPalaceAtMingKr"],
        sihua=sihua_str,
        sihua_pal=sihua_pal,
        liuyue=liuyue_str,
        palaces=palaces_str,
    )

# ── 프롬프트 3종 ──────────────────────────────────────────────

def _prompt_free(d):
    return f"""아래 자미두수 명반을 보고 무료 미리보기를 작성하세요.

명궁: {d['ming_gong_zhi']} / 오행국: {d['wu_xing_ju']} / 명궁 주성: {d['ming_stars']}
현재 대한: {d['dax_age']}세 ({d['dax_palace']} {d['dax_ganzhi']})

150자 이내로, 이 사람의 타고난 핵심 기질 한 줄 + 지금 대한의 분위기 한 줄만 직언하세요.
마지막은 반드시 "전체 운세에서 더 충격적인 내용을 확인하세요."로 끝내세요."""

def _prompt_year(d):
    return f"""아래 자미두수 명반으로 {d['current_year']}년 해별 운세를 작성하세요.

[명반]
명궁: {d['ming_gong_zhi']} / 오행국: {d['wu_xing_ju']} / 주성: {d['ming_stars']}
신궁: {d['shen_gong_zhi']}
현재 대한: {d['dax_age']}세 / {d['dax_palace']}({d['dax_ganzhi']}) / 주성: {d['dax_stars']}
유년명궁: {d['liunian_palace']} / 사화: {d['sihua']}
사화궁위: {d['sihua_pal']}

[월별 유월명궁]
{d['liuyue']}

아래 순서로 직설적으로 작성하세요:

1. {d['current_year']}년 총평 (3줄) — 이 해의 핵심 키워드와 가장 강렬한 변화 예고
2. 재물운 — 돈이 들어오는 달, 나가는 달 구체적으로 지목
3. 직업·사업운 — 기회의 달, 위험의 달 직언
4. 건강운 — 주의할 신체 부위와 시기
5. 인간관계·이성운 — 만남, 이별, 갈등 시기 직언
6. 월별 핵심 포인트 (1월~12월) — 각 월 2~3줄, 구체적 행동 지침 포함
7. 올해 절대 하면 안 되는 것 / 반드시 해야 할 것"""

def _prompt_day(d, liuri):
    return f"""아래 자미두수 명반으로 특정일 운세를 작성하세요.

[명반]
명궁: {d['ming_gong_zhi']} / 오행국: {d['wu_xing_ju']} / 주성: {d['ming_stars']}
현재 대한: {d['dax_age']}세 / {d['dax_palace']}({d['dax_ganzhi']})
유년명궁: {d['liunian_palace']}

[조회일]
{d['current_year']}년 {liuri['queryMonth']}월 {liuri['queryDay']}일
유월명궁: {liuri['monthPalaceKr']} / 유일명궁: {liuri['palaceNameKr']}({liuri['mingGongZhi']})

아래 순서로 이 날 하루를 직설적으로 풀이하세요:

1. 이 날의 전체 기운 (2줄) — 길일인가 흉일인가 단호하게 판정
2. 재물·계약 — 오늘 돈 거래·계약·투자 해도 되는가 직언
3. 직업·시험·면접 — 오늘 중요한 결정·시험에 유리한가 불리한가
4. 건강·이동 — 오늘 주의할 것
5. 이성·인간관계 — 오늘 만남, 연락, 고백 타이밍
6. 오늘 해야 할 것 / 하면 안 될 것 (각 3가지씩 단호하게)
7. 한줄 총평 — 이 날을 한 문장으로 요약"""

# ── 메인 생성 함수 ────────────────────────────────────────────

async def generate_ziwei_reading(mingban: dict, service_type: str,
                                  current_year: int, liuri=None) -> str:
    d = _extract(mingban, current_year)

    if service_type == "ziwei_free":
        prompt, tokens = _prompt_free(d), 400
    elif service_type == "ziwei_year":
        prompt, tokens = _prompt_year(d), 6000
    else:  # ziwei_day
        prompt, tokens = _prompt_day(d, liuri), 3000

    resp = await client.chat.completions.create(
        model="gpt-4o",
        max_tokens=tokens,
        messages=[
            {"role": "system", "content": SYSTEM},
            {"role": "user",   "content": prompt},
        ],
    )
    return _clean(resp.choices[0].message.content)
